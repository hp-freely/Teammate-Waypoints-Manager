////
// One feature that was never included in T2 was the ability to have perma IFFs for teammates. This type of behavior is incredily important for coordination, especially in 
// fast paced game modes like LT. One workaround for this has been to co-opt T2's waypoint system. T2 shipped with the ability to add waypoints on the *map* via the CC. 
// However, it never provided out-of-the-box functionality to waypoint teammates (or any other object). That said, T2's game engine does *not* prohibit such an action. So,
// from this, BuddyPoints and AutoPoints was born. BuddyPoints allows you to *manually* add waypoints for teammates via the CC. Autopoints allows you to automatically create
// waypoints for teammates. However, again, due to the underlying structure of T2, AutoPoints was abused to create perma-waypoints for *enemy* players as well. So, a feature
// that, in my opinion, is a necessary component of team cordination, was abused to track enemy player movements as well (as long as they were in sensor range).
//
// Autopoints was finally blocked with changes made to Taco's T2 server code. Unfortunately, with those changes, we also lost the ability to easily create automatic teammate
// waypoints as well. Beyond that, the changes also impacted BuddyPoints - the script would still create waypoints players, but the waypoint would no longer show the *name*
// of the player associated with the waypoint (in other words, an empty waypoint icon). This because the data necessary for player names was no longer available.
//
// The above context provided, the purpose of this script is to support both *manual and automatic* waypoints for *teammates only*, where those waypoints *display player names*.
// How does it accomplish this? It actually borrows from a solution that Ilys created in a couple of scripts (ex: Team Asset Finder). It works by referencing player data directly
// from the CC Commander Tree. 
//
// The overall summary of behavior is:
//   1) The script retrieves a list of teammate player targets from the CC (the "Clients" menu). However, this information is *only* updated when the CC is opened. This means that
//      the script must manually focus the CC *behind the scenes* in order to get a snapshot of player data. This also means that the script must ensure that focusing the CC
//      does not interfere with the user's normal behavior.
//   2) While the CC does given you access to teammates, it *does not* give you any context about *who* that player is (i.e. their name). In order to get this information, 
//      the script must create a task for that player (ex: Escort Player Player or Repair Player). Then, the script must reference an overridable task function, 
//      clientCmdTaskInfo(), and *that* function will actually give us context on what that player is.
//   3) The presents an issue where a) the script must wait on the task creation callback, but b) the script must *not* create a task for *any other player* until the callback
//      has been processed. Else, we run into race conditions where a *second* player might be evaluated from the CC before the *first* player was processed. It's a very delicate balance.
//   4) Finally, there are a ton of nuanced conditions that must be handled as well as a result of a) the complicated structure described above, and b) incredibly frustrating
//      core T2 behavior as well as underlying bugs discovered along the way.
//
// Regarding #3 and #4 above, this script could not be more complicated, because of the incredibly frustrating nature of how T2 makes data available. Some of these include (but are not limited to):
//   1) There appears to be some limit / threshold that prevents T2 from either a) sending too many targets to the server or b) creating too many player *tasks* within a "short"
//      period of time. If you try to create too many tasks, then T2 will simply fail the request. As a result, player tasks must be created *very slowly* (more on this further below).
//   2) A core piece of the script logic relies on knowing whether or not the match has started *by countdown* vs the match has started *by time*. However, T2 actually does not make
//      make it simple to retrieve the current game time. Rather, it relies on a callback, and that callback occurs every 20 seconds. It is very possible for a player to join a map,
//      and that map is active, but the script still hasn't receive any information on whether or not the map is *active by time*.
//   3) Similar to #2, when a player joins a map, T2 may not immediately make player data available to the CC. There seems to be a potential for some lag on performing this update.
//      As a result, the script has to make special assurances that CC player data *is available* before it tries to process waypoints.
//
// Given all of the above, there are some important restrictions that must be forced on the user. The restrictions are as follows:
//   1) As mentioned above, this script requires certain data to be available to the client in order to process waypoints. It is *not* predictable when that data will be made available
//      As a result, it can take a long period of time for the script to even begin processing waypoints. For example, upon joining an active match, I have had to wait up to 30 seconds
//      for this required data to be made available. Given this, if you wish to create waypoints *with player names*, then you may have to just be patient for the waypoints to appear.
//   2) A server takes a certain amount of time to process a given player target. How much time it takes depends on a) the server in question, and b) your latency to that server. I have found
//      that it takes about 1000ms (1 second) for a given server to a) process a player target, b) create a client task for that target, and c) return that task to the client. For that reason,
//      one say that it takes an average of 1 second per player to add all required waypoints.
//   3) The script completely removes the ability to create a "Repair Player" task for players. I chose the "Repair Player" task to be used when creating a waypoint for players
//      from the CC (as described in the above section), because T2 forces me to use a core, supported task option. Otherwise, the callback functions won't work as I need them
//      to. I chose "Repair Player", because it is probably the least likely to be used these days. 
//
//      The reason I need to remove "Repair Player" is because the script *cannot* have a user accidentally calling it. The issue is: a) the CC provides the Player ID, and b)
//      the callback task function provides the player name. However, *neither* provide both. If a user creates a "Repair Player" task, and the script also creates a task
//      for an player, then a race condition could occur where the script tracks the *wrong* player. I would consider this even to be rare, but there's no reason not to
//      to prevent it.
//   4) Related to the above, when a player waypoint is created with a name, the user will always see "Repair Player..." text displayed on top of the player receiving the waypoint for a
//		short period of time. There is *no* way to get around this. It is a core part of the engine that cannot be worked around.
//   5) The script will never allow the CC to be displayed in demos. The reason for this is, as described in the above section, the script must be able to continuously focus
//      the CC in order get updated deployed asset data. When the user is playing the game, this focus action happens behind the scenes, and the user isn't aware of it.
//      However, for reasons I don't understand, this "behind the scenes" action does not work in demos. As a result, if a special action is not taken, then the CC would
//      *always* be displayed in the demo. I feel this is a very small restriction to deal with.
//   6) The player waypoints will *not* be displayed when viewing a demo. I actually don't know exactly why this occurs. I assume it has to do with how demos process data in 
//      real time as if the match was happening live. In other words, demos are not a snapshot in time. The script has explicit logic that says it will not process waypoints
//      when a player is in observer. When viewing a demo, a player is always on the observer *team*, which means waypoints should never be processed. Again, it's weird. I did
//      not spend much time exploring this.
//
// *Known Issues*
// Below are some issues that I know exist:
//   1) As described above, adding waypoints with player names is a slow process. It will take *at least* one second to process a waypoint for each member of your team. It may take more
//      time than that, depending on the server and connection latency.
//   2) I have experienced the issue where, the script will create a waypoint for a teammate, but a waypoint doesn't immediately show. Then, after the player dies and respawns, then the
//      waypoint suddenly appears. My theory is that the script attempts to apply the waypoint when the player is currently dead and *has not yet respawned*. This creates some weird state
//      where the waypoint doesn't get applied until the next respawn. This is just a theory though.
//   3) I have rarely experienced the issue where a) a waypoint is applied, but then b) the waypoint is then *removed* afterwards for no expected reason. I do not know why this occurs.
//      Even going through my script logs, I can see that my script explicitly removes the waypoint. For some reason, it felt that the player did not exist, even though they did. If this occurs
//      you'll have to manually re-add the waypoint. There's no other way, barring the player leaving the game or switching to the other team.
////

BuddyPoints
I recommend removing the BuddyPoints script entirely. There should be no conflict in running both at the sametime. However, removing it reduces confusion, because 
the options in the CC are very similar

Dependencies
You must ensure you support the following dependencies:
1. HudManager.vl2
2. UberGuy's Script Suite. 
   (I am unsure what supports this. This must include: a) Scripts tab in the browser, b) UberPrefs support. Both of the these are included in the all-in-one download.)
	
Instructions
1. Move TeammateWaypointManager.vl2 to your z_scripts or scripts folder
2. [Optional] Feel free to move prefs/TeammateWaypointManagerPrefs.cs to your base/prefs folder. However, this is not necessary, unless you want to add support for
   additional game modes.
3. Use the browser Script tab to set your automated waypoint configuration as desired.