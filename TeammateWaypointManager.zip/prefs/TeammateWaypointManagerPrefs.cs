////
// This prefs file is only useful for configuring the items below. No other variables require custom configuration, except in potentially exceptional circumstances
////

	// the following list of game modes support adding waypoints for teammates. If any game mode is missing, then it can be simply added to
	// the bottom of this list, and it will be dynamically supported.
	// An example of a game mode that a) has teammates, but b) makes zero sense for waypoints would be Lak.
supportedGameModes[0] = "Arena";
supportedGameModes[1] = "CTF";
supportedGameModes[2] = "Capture the Flag";		
supportedGameModes[3] = "Capture the Flag (Practice)";
supportedGameModes[4] = "Capture and Hold";
supportedGameModes[5] = "Conquest";
supportedGameModes[6] = "Defend and Destroy";
supportedGameModes[7] = "Deathmatch";
supportedGameModes[8] = "Hybrid";
supportedGameModes[9] = "Siege";
supportedGameModes[10] = "Team Deathmatch";
supportedGameModes[11] = "LCTF";
supportedGameModes[12] = "Spawn CtF";
supportedGameModes[13] = "Team Hunters";
supportedGameModes[14] = "Team Rabbit 2";		